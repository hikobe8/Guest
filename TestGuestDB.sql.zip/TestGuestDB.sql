-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- 主机: localhost
-- 生成日期: 2015 年 12 月 15 日 15:59
-- 服务器版本: 5.0.51
-- PHP 版本: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- 数据库: `testguest`
-- 
CREATE DATABASE `testguest` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `testguest`;

-- --------------------------------------------------------

-- 
-- 表的结构 `tg_user`
-- 

CREATE TABLE `tg_user` (
  `tg_id` mediumint(8) unsigned NOT NULL auto_increment COMMENT '\\\\用户id',
  `tg_uniqid` char(40) NOT NULL COMMENT '\\\\用户唯一标识符',
  `tg_username` varchar(20) NOT NULL COMMENT '\\\\用户名',
  `tg_password` char(40) NOT NULL COMMENT '\\\\密码',
  `tg_question` varchar(20) NOT NULL COMMENT '\\\\密码提示',
  `tg_answer` char(40) NOT NULL COMMENT '\\\\密码提示答案',
  `tg_email` varchar(40) default NULL COMMENT '\\\\邮箱',
  `tg_qq` varchar(10) default NULL COMMENT '\\\\QQ',
  `tg_url` varchar(40) default NULL COMMENT '\\\\网址',
  `tg_active` char(40) NOT NULL COMMENT '\\\\激活账户的唯一标识符',
  `tg_sex` char(1) NOT NULL COMMENT '\\\\性别',
  `tg_face` char(12) NOT NULL COMMENT '\\\\头像',
  `tg_reg_time` datetime NOT NULL COMMENT '\\\\注册时间',
  `tg_last_time` datetime NOT NULL COMMENT '\\\\最后登录时间',
  `tg_last_ip` varchar(20) NOT NULL COMMENT '\\\\最后登录ip',
  PRIMARY KEY  (`tg_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- 导出表中的数据 `tg_user`
-- 

